namespace Task3_variant3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox2.Text = trackBar1.Value.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox2.Text = trackBar1.Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Value = progressBar1.Minimum;
            textBox3.Text = "";
            if (string.IsNullOrEmpty(textBox1.Text)) return;

            int result = 1;
            int numberToRaise = int.Parse(textBox1.Text);
            int power = (int)numericUpDown1.Value;
            int maxPower = power;

            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = trackBar1.Value * 1000;

            timer.Enabled = true;
            timer.Tick += delegate
            {
                result *= numberToRaise;
                textBox3.Text = result.ToString();
                progressBar1.Value = progressBar1.Maximum * (maxPower - power + 1) / maxPower;

                power -= 1;
                if (power == 0)
                {
                    timer.Enabled = false;
                    timer.Stop();
                }
            };
            timer.Start();

        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) return;
            if (Char.IsControl(e.KeyChar)) return;
            e.Handled = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}