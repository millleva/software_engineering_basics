using System.Windows.Forms;

namespace task1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) return;
            if (Char.IsControl(e.KeyChar)) return;
            e.Handled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numberToRaise = int.Parse(textBox1.Text);
            int power = (int)numericUpDown1.Value;
            int result = 1;
            for (int step = 1; step <= power; step++)
            {
                progressBar1.Value = progressBar1.Maximum * step / power;
                result *= numberToRaise;
                textBox2.Text = result.ToString();
                Thread.Sleep(1000);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}