﻿namespace Task_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pressMeButton = new Button();
            buttonSpeedLabel = new Label();
            buttonSpeedNumericUpDown = new NumericUpDown();
            mouseCoordinatesLabel = new Label();
            buttonCoordinatesLabel = new Label();
            ((System.ComponentModel.ISupportInitialize)buttonSpeedNumericUpDown).BeginInit();
            SuspendLayout();
            // 
            // pressMeButton
            // 
            pressMeButton.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            pressMeButton.Location = new Point(286, 297);
            pressMeButton.Name = "pressMeButton";
            pressMeButton.Size = new Size(179, 61);
            pressMeButton.TabIndex = 0;
            pressMeButton.Text = "Press me!";
            pressMeButton.UseVisualStyleBackColor = true;
            pressMeButton.Click += pressMeButton_Click;
            pressMeButton.MouseEnter += pressMeButton_MouseEnter;
            // 
            // buttonSpeedLabel
            // 
            buttonSpeedLabel.AutoSize = true;
            buttonSpeedLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            buttonSpeedLabel.Location = new Point(12, 88);
            buttonSpeedLabel.Name = "buttonSpeedLabel";
            buttonSpeedLabel.Size = new Size(127, 25);
            buttonSpeedLabel.TabIndex = 3;
            buttonSpeedLabel.Text = "Button speed:";
            // 
            // buttonSpeedNumericUpDown
            // 
            buttonSpeedNumericUpDown.Location = new Point(145, 90);
            buttonSpeedNumericUpDown.Name = "buttonSpeedNumericUpDown";
            buttonSpeedNumericUpDown.Size = new Size(36, 23);
            buttonSpeedNumericUpDown.TabIndex = 4;
            buttonSpeedNumericUpDown.ValueChanged += buttonSpeedNumericUpDown_ValueChanged;
            // 
            // mouseCoordinatesLabel
            // 
            mouseCoordinatesLabel.AutoSize = true;
            mouseCoordinatesLabel.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            mouseCoordinatesLabel.Location = new Point(12, 9);
            mouseCoordinatesLabel.Name = "mouseCoordinatesLabel";
            mouseCoordinatesLabel.Size = new Size(190, 30);
            mouseCoordinatesLabel.TabIndex = 5;
            mouseCoordinatesLabel.Text = "Mouse coordinates";
            // 
            // buttonCoordinatesLabel
            // 
            buttonCoordinatesLabel.AutoSize = true;
            buttonCoordinatesLabel.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            buttonCoordinatesLabel.Location = new Point(12, 47);
            buttonCoordinatesLabel.Name = "buttonCoordinatesLabel";
            buttonCoordinatesLabel.Size = new Size(189, 30);
            buttonCoordinatesLabel.TabIndex = 6;
            buttonCoordinatesLabel.Text = "Button coordinates";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonCoordinatesLabel);
            Controls.Add(mouseCoordinatesLabel);
            Controls.Add(buttonSpeedNumericUpDown);
            Controls.Add(buttonSpeedLabel);
            Controls.Add(pressMeButton);
            Name = "Form1";
            Text = "Task_1";
            MouseMove += Form1_MouseMove;
            ((System.ComponentModel.ISupportInitialize)buttonSpeedNumericUpDown).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button pressMeButton;
        private Label buttonSpeedLabel;
        private NumericUpDown buttonSpeedNumericUpDown;
        private Label mouseCoordinatesLabel;
        private Label buttonCoordinatesLabel;
    }
}