using System;
using System.Drawing;
using System.Windows.Forms;

namespace Task_1
{
    public partial class Form1 : Form
    {
        private int buttonSpeed;
        private Point initialButtonPosition;
        public Form1()
        {
            InitializeComponent();
            buttonSpeed = (int)buttonSpeedNumericUpDown.Value;
            initialButtonPosition = pressMeButton.Location;
        }

        private void pressMeButton_MouseEnter(object sender, EventArgs e)
        {
            MoveButtonAwayFromCursor();
        }


        private void MoveButtonAwayFromCursor()
        {
            Random random = new Random();
            Point cursorPosition = Cursor.Position;
            Point buttonPosition = pressMeButton.Location;

            int deltaX = random.Next(-buttonSpeed, buttonSpeed + 1);
            int deltaY = random.Next(-buttonSpeed, buttonSpeed + 1);

            int newX = buttonPosition.X + deltaX;
            int newY = buttonPosition.Y + deltaY;

            newX = Math.Max(0, Math.Min(newX, this.ClientSize.Width - pressMeButton.Width));
            newY = Math.Max(0, Math.Min(newY, this.ClientSize.Height - pressMeButton.Height));

            pressMeButton.Location = new Point(newX, newY); ;

            buttonCoordinatesLabel.Text = $"Button coordinates: ({newX}, {newY})";
        }

        private void pressMeButton_Click(object sender, EventArgs e)
        {
            ShowVictoryDialog();
        }

        private void ShowVictoryDialog()
        {
            pressMeButton.Enabled = false;
            MessageBox.Show("You won! Try again", "Congratulations", MessageBoxButtons.OK);
            pressMeButton.Enabled = true;
            ResetButtonPosition();
        }

        private void ResetButtonPosition()
        {
            pressMeButton.Location = initialButtonPosition;
            buttonCoordinatesLabel.Text = $"Button coordinates: ({initialButtonPosition.X}, {initialButtonPosition.Y})";
        }


        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            mouseCoordinatesLabel.Text = $"Mouse coordinates: ({e.X}, {e.Y})";

        }

        private void buttonSpeedNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            buttonSpeed = (int)buttonSpeedNumericUpDown.Value;
        }
    }
}