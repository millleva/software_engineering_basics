using System;
using System.Windows.Forms;

namespace Task_3
{
    public partial class Form1 : Form
    {
        private int clickCounter = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void helloLabel_MouseClick(object sender, MouseEventArgs e)
        {
            clickCounter++;
            if (clickCounter == 3)
            {
                clickCounter = 0;
                helloLabel.Font = new Font("Cooper", 20F, FontStyle.Underline , GraphicsUnit.Point);
                helloLabel.ForeColor = Color.Red;
                helloLabel.BackColor = Color.Yellow;
                Random random = new Random();
                helloLabel.Left = random.Next(0, this.ClientSize.Width - helloLabel.Width);
                helloLabel.Top = random.Next(0, this.ClientSize.Height - helloLabel.Height);

            }
        }
    }
}