using System;
using System.Drawing;
using System.Windows.Forms;

namespace Task_2
{
    public partial class Form1 : Form
    {
        private Point previousLocation;
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox_MouseDown(object sender, MouseEventArgs e)
        {
            previousLocation = e.Location;
        }

        private void pictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pictureBox.Left += e.X - previousLocation.X;
                pictureBox.Top += e.Y - previousLocation.Y;

                ClampPictureBoxToBounds();
                UpdateLocationLabel();
                CheckCurrentArea();
            }
        }

        private void ClampPictureBoxToBounds()
        {
            if (pictureBox.Left < 0)
                pictureBox.Left = 0;
            if (pictureBox.Top < 0)
                pictureBox.Top = 0;
            if (pictureBox.Right > ClientSize.Width)
                pictureBox.Left = ClientSize.Width - pictureBox.Width;
            if (pictureBox.Bottom > ClientSize.Height)
                pictureBox.Top = ClientSize.Height - pictureBox.Height;
        }

        private void pictureBox_MouseUp(object sender, MouseEventArgs e)
        {
            CheckCurrentArea();

            Point centerOfArea = Point.Empty;
            if (locationLabel.Text == "Top Left")
            {
                centerOfArea = new Point(ClientSize.Width / 4, ClientSize.Height / 4);
            }
            else if (locationLabel.Text == "Top Right")
            {
                centerOfArea = new Point(3 * ClientSize.Width / 4, ClientSize.Height / 4);
            }
            else if (locationLabel.Text == "Bottom Left")
            {
                centerOfArea = new Point(ClientSize.Width / 4, 3 * ClientSize.Height / 4);
            }
            else if (locationLabel.Text == "Bottom Right")
            {
                centerOfArea = new Point(3 * ClientSize.Width / 4, 3 * ClientSize.Height / 4);
            }
            else
            {
                centerOfArea = new Point(ClientSize.Width / 2, ClientSize.Height / 2);
            }

            int newLeft = centerOfArea.X - pictureBox.Width / 2;
            int newTop = centerOfArea.Y - pictureBox.Height / 2;

            pictureBox.Location = new Point(newLeft, newTop);
            UpdateLocationLabel();
        }

        private void CheckCurrentArea()
        {
            Rectangle area1 = new Rectangle(0, 0, ClientSize.Width / 2, ClientSize.Height / 2);
            Rectangle area2 = new Rectangle(ClientSize.Width / 2, 0, ClientSize.Width / 2, ClientSize.Height / 2);
            Rectangle area3 = new Rectangle(0, ClientSize.Height / 2, ClientSize.Width / 2, ClientSize.Height / 2);
            Rectangle area4 = new Rectangle(ClientSize.Width / 2, ClientSize.Height / 2, ClientSize.Width / 2, ClientSize.Height / 2);

            Rectangle pictureBoxRect = new Rectangle(pictureBox.Left, pictureBox.Top, pictureBox.Width, pictureBox.Height);

            if (area1.Contains(pictureBoxRect))
            {
                locationLabel.Text = "Top Left";
            }
            else if (area2.Contains(pictureBoxRect))
            {
                locationLabel.Text = "Top Right";
            }
            else if (area3.Contains(pictureBoxRect))
            {
                locationLabel.Text = "Bottom Left";
            }
            else if (area4.Contains(pictureBoxRect))
            {
                locationLabel.Text = "Bottom Right";
            }
            else
            {
                locationLabel.Text = "Crossroads";
            }
        }

        private void UpdateLocationLabel()
        {
            coordinatesLabel.Text = $"X: {pictureBox.Left}, Y: {pictureBox.Top}";
        }

    }
}