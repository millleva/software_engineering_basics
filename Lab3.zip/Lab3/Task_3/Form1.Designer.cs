﻿namespace Task_3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            compareOrdinalButton = new Button();
            compareOrdinalResult = new Label();
            label2 = new Label();
            label3 = new Label();
            compareToButton = new Button();
            substringButton = new Button();
            compareToResult = new Label();
            substringResult = new Label();
            textBox3 = new TextBox();
            substringResultLabel = new Label();
            startIndexTextBox = new TextBox();
            startIndexLabel = new Label();
            lengthTextBox = new TextBox();
            lengthLabel = new Label();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(35, 44);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(127, 23);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(207, 44);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(127, 23);
            textBox2.TabIndex = 1;
            // 
            // compareOrdinalButton
            // 
            compareOrdinalButton.Location = new Point(35, 83);
            compareOrdinalButton.Name = "compareOrdinalButton";
            compareOrdinalButton.Size = new Size(127, 31);
            compareOrdinalButton.TabIndex = 2;
            compareOrdinalButton.Text = "CompareOrdinal";
            compareOrdinalButton.UseVisualStyleBackColor = true;
            compareOrdinalButton.Click += compareOrdinalButton_Click;
            // 
            // compareOrdinalResult
            // 
            compareOrdinalResult.AutoSize = true;
            compareOrdinalResult.Location = new Point(35, 128);
            compareOrdinalResult.Name = "compareOrdinalResult";
            compareOrdinalResult.Size = new Size(39, 15);
            compareOrdinalResult.TabIndex = 3;
            compareOrdinalResult.Text = "Result";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(73, 26);
            label2.Name = "label2";
            label2.Size = new Size(47, 15);
            label2.TabIndex = 4;
            label2.Text = "String 1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(246, 26);
            label3.Name = "label3";
            label3.Size = new Size(47, 15);
            label3.TabIndex = 5;
            label3.Text = "String 2";
            // 
            // compareToButton
            // 
            compareToButton.Location = new Point(207, 83);
            compareToButton.Name = "compareToButton";
            compareToButton.Size = new Size(127, 31);
            compareToButton.TabIndex = 6;
            compareToButton.Text = "CompareTo";
            compareToButton.UseVisualStyleBackColor = true;
            compareToButton.Click += compareToButton_Click;
            // 
            // substringButton
            // 
            substringButton.Location = new Point(35, 265);
            substringButton.Name = "substringButton";
            substringButton.Size = new Size(127, 31);
            substringButton.TabIndex = 7;
            substringButton.Text = "Substring";
            substringButton.UseVisualStyleBackColor = true;
            substringButton.Click += substringButton_Click;
            // 
            // compareToResult
            // 
            compareToResult.AutoSize = true;
            compareToResult.Location = new Point(207, 128);
            compareToResult.Name = "compareToResult";
            compareToResult.Size = new Size(39, 15);
            compareToResult.TabIndex = 8;
            compareToResult.Text = "Result";
            // 
            // substringResult
            // 
            substringResult.AutoSize = true;
            substringResult.Location = new Point(177, 281);
            substringResult.Name = "substringResult";
            substringResult.Size = new Size(39, 15);
            substringResult.TabIndex = 9;
            substringResult.Text = "Result";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(35, 220);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(127, 23);
            textBox3.TabIndex = 10;
            // 
            // substringResultLabel
            // 
            substringResultLabel.AutoSize = true;
            substringResultLabel.Location = new Point(73, 202);
            substringResultLabel.Name = "substringResultLabel";
            substringResultLabel.Size = new Size(47, 15);
            substringResultLabel.TabIndex = 11;
            substringResultLabel.Text = "String 3";
            // 
            // startIndexTextBox
            // 
            startIndexTextBox.Location = new Point(177, 220);
            startIndexTextBox.Name = "startIndexTextBox";
            startIndexTextBox.Size = new Size(63, 23);
            startIndexTextBox.TabIndex = 12;
            // 
            // startIndexLabel
            // 
            startIndexLabel.AutoSize = true;
            startIndexLabel.Location = new Point(177, 202);
            startIndexLabel.Name = "startIndexLabel";
            startIndexLabel.Size = new Size(63, 15);
            startIndexLabel.TabIndex = 14;
            startIndexLabel.Text = "Start index";
            // 
            // lengthTextBox
            // 
            lengthTextBox.Location = new Point(246, 220);
            lengthTextBox.Name = "lengthTextBox";
            lengthTextBox.Size = new Size(63, 23);
            lengthTextBox.TabIndex = 15;
            // 
            // lengthLabel
            // 
            lengthLabel.AutoSize = true;
            lengthLabel.Location = new Point(246, 202);
            lengthLabel.Name = "lengthLabel";
            lengthLabel.Size = new Size(44, 15);
            lengthLabel.TabIndex = 16;
            lengthLabel.Text = "Length";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(461, 341);
            Controls.Add(lengthLabel);
            Controls.Add(lengthTextBox);
            Controls.Add(startIndexLabel);
            Controls.Add(startIndexTextBox);
            Controls.Add(substringResultLabel);
            Controls.Add(textBox3);
            Controls.Add(substringResult);
            Controls.Add(compareToResult);
            Controls.Add(substringButton);
            Controls.Add(compareToButton);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(compareOrdinalResult);
            Controls.Add(compareOrdinalButton);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Task 3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private Button compareOrdinalButton;
        private Label compareOrdinalResult;
        private Label label2;
        private Label label3;
        private Button compareToButton;
        private Button substringButton;
        private Label compareToResult;
        private Label substringResult;
        private TextBox textBox3;
        private Label substringResultLabel;
        private TextBox startIndexTextBox;
        private Label startIndexLabel;
        private TextBox lengthTextBox;
        private Label lengthLabel;
    }
}