namespace Task_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;
            string[] parts = input.Split(' ');

            if (parts.Length == 3)
            {
                double firstOperand;
                double secondOperand;
                double result;

                if (double.TryParse(parts[0], out firstOperand) && double.TryParse(parts[2], out secondOperand))
                {
                    string operation = parts[1];

                    switch (operation.ToLower())
                    {
                        case "plus":
                        case "+":
                            result = firstOperand + secondOperand;
                            outputTextBox.Text = result.ToString();
                            break;
                        case "minus":
                        case "-":
                            result = firstOperand - secondOperand;
                            outputTextBox.Text = result.ToString();
                            break;
                        case "multiply":
                        case "*":
                            result = firstOperand * secondOperand;
                            outputTextBox.Text = result.ToString();
                            break;
                        case "divide":
                        case "/":
                            if (secondOperand != 0)
                            {
                                result = firstOperand / secondOperand;
                                outputTextBox.Text = result.ToString();
                            }
                            else
                            {
                                outputTextBox.Text = "Cannot divide by zero.";
                            }
                            break;
                        default:
                            outputTextBox.Text = "Invalid operation.";
                            break;
                    }
                }
                else
                {
                    outputTextBox.Text = "Invalid input format.";
                }
            }
            else
            {
                outputTextBox.Text = "Invalid input format.";
            }
        }
    }
}