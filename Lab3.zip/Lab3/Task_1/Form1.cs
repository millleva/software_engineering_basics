using System.Text;

namespace Task_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string ArchiveText(string input)
        {
            StringBuilder output = new StringBuilder();

            char currentChar = '\0';
            int charCount = 0;

            foreach (char c in input)
            {
                if (c == currentChar)
                {
                    charCount++;
                }
                else
                {
                    if (currentChar != '\0')
                    {
                        output.Append(currentChar);
                        if (charCount > 1)
                        {
                            output.Append(charCount.ToString());
                        }
                    }

                    currentChar = c;
                    charCount = 1;
                }
            }

            if (currentChar != '\0')
            {
                output.Append(currentChar);
                if (charCount > 1)
                {
                    output.Append(charCount.ToString());
                }
            }

            return output.ToString();
        }

        private void archiveButton_Click(object sender, EventArgs e)
        {
            string input = archiveTextBox.Text;
            string output = ArchiveText(input);
            dearchiveTextBox.Text = output;

        }

        private string DearchiveText(string input)
        {
            StringBuilder output = new StringBuilder();

            for (int i = 0; i < input.Length; i++)
            {
                char c = input[i];

                if (char.IsDigit(c) && i > 0 && char.IsLetter(input[i - 1]))
                {
                    int count = int.Parse(c.ToString());
                    if (count > 1)
                    {
                        output.Append(new string(input[i - 1], count - 1));
                    }
                }
                else
                {
                    output.Append(c);
                }
            }

            return output.ToString();
        }

        private void dearchiveButton_Click(object sender, EventArgs e)
        {
            string input = dearchiveTextBox.Text;
            string output = DearchiveText(input);
            archiveTextBox.Text = output;

        }
    }
}