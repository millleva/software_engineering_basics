using System.Drawing;

namespace opi7_1
{
    public partial class Paint : Form
    {
        public Paint()
        {
            InitializeComponent();
            SetSize();
        }
        private bool isMouse = false;
        Point startLocatoin, endLocation;
        private Bitmap map = new Bitmap(100, 100);
        private string figure;
        private Graphics graphics;
        private Pen pen = new Pen(Color.Black, 3f);
        private ArrayPoints arrayPoints = new ArrayPoints(2);
        private void paintBox_MouseDown(object sender, MouseEventArgs e)
        {
            isMouse = true;
            startLocatoin = e.Location;
        }
        private void paintBox_MouseUp(object sender, MouseEventArgs e)
        {
            isMouse = false;
            arrayPoints.ResetPoint();
        }
        private void paintBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (!isMouse)
            {
                return;
            }
            endLocation = e.Location;
            arrayPoints.SetPoint(e.X, e.Y);
            if (arrayPoints.GetCountPoints() >= 2)
            {
                switch (figure)
                {
                    case "Line":
                        graphics.DrawLine(pen, startLocatoin, endLocation);
                        paintBox.Image = map;
                        arrayPoints.SetPoint(e.X, e.Y);
                        break;
                    case "Elps":
                        graphics.DrawEllipse(pen, startLocatoin.X, startLocatoin.Y,
                            (endLocation.X - startLocatoin.X), (endLocation.Y - startLocatoin.Y));
                        paintBox.Image = map;
                        arrayPoints.SetPoint(e.X, e.Y);
                        break;
                    case "Rntn":
                        graphics.DrawRectangle(pen, startLocatoin.X, startLocatoin.Y,
                            (endLocation.X - startLocatoin.X), (endLocation.Y - startLocatoin.Y));
                        paintBox.Image = map;
                        arrayPoints.SetPoint(e.X, e.Y);
                        break;
                    case "Fill":
                        paintBox.BackColor = pen.Color;
                        arrayPoints.SetPoint(e.X, e.Y);
                        break;
                    case "Pen":
                        graphics.DrawLines(pen, arrayPoints.GetPoints());
                        paintBox.Image = map;
                        arrayPoints.SetPoint(e.X, e.Y);
                        break;
                }
            }
        }
        private void SetSize()
        {
            Rectangle rectangle = Screen.PrimaryScreen.Bounds;
            map = new Bitmap(rectangle.Width, rectangle.Height);
            graphics = Graphics.FromImage(map);

            pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
        }
        private void color_Click(object sender, EventArgs e)
        {
            pen.Color = ((Button)sender).BackColor;
        }
        private void clear_Click(object sender, EventArgs e)
        {
            graphics.Clear(paintBox.BackColor);
            paintBox.Image = map;
        }
        private void lineWeight_ValueChanged(object sender, EventArgs e)
        {
            pen.Width = lineWeight.Value;
        }
        private void save_Click(object sender, EventArgs e)
        {
            saveFile.Filter = "JPG(*.JPG)|*.jpg";
            saveFile.ShowDialog();
            if (saveFile.FileName != "")
            {
                paintBox.Image.Save(saveFile.FileName);
            }
        }
        private void figure_Click(object sender, EventArgs e)
        {
            figure = ((Button)sender).Text;
        }
    }
}