﻿namespace opi7_1
{
    partial class Paint
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Paint));
            groupBox1 = new GroupBox();
            panel3 = new Panel();
            label3 = new Label();
            drPen = new Button();
            drRentangle = new Button();
            drFill = new Button();
            drEllips = new Button();
            drLine = new Button();
            panel2 = new Panel();
            lineWeight = new TrackBar();
            label2 = new Label();
            panel1 = new Panel();
            clrPink = new Button();
            clrBrown = new Button();
            clrYellow = new Button();
            label1 = new Label();
            clrOrange = new Button();
            clrViolet = new Button();
            clrDarkBlue = new Button();
            clrBlue = new Button();
            clrGreen = new Button();
            clrRed = new Button();
            clrBlack = new Button();
            clrGray = new Button();
            clrWhite = new Button();
            clear = new Button();
            save = new Button();
            paintBox = new PictureBox();
            saveFile = new SaveFileDialog();
            groupBox1.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)lineWeight).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)paintBox).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Gainsboro;
            groupBox1.Controls.Add(panel3);
            groupBox1.Controls.Add(panel2);
            groupBox1.Controls.Add(panel1);
            groupBox1.Controls.Add(clear);
            groupBox1.Controls.Add(save);
            groupBox1.Dock = DockStyle.Top;
            groupBox1.Location = new Point(0, 0);
            groupBox1.Margin = new Padding(2, 2, 2, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(2, 2, 2, 2);
            groupBox1.Size = new Size(655, 89);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Tools";
            // 
            // panel3
            // 
            panel3.BorderStyle = BorderStyle.Fixed3D;
            panel3.Controls.Add(label3);
            panel3.Controls.Add(drPen);
            panel3.Controls.Add(drRentangle);
            panel3.Controls.Add(drFill);
            panel3.Controls.Add(drEllips);
            panel3.Controls.Add(drLine);
            panel3.Dock = DockStyle.Left;
            panel3.Location = new Point(379, 18);
            panel3.Margin = new Padding(2, 2, 2, 2);
            panel3.Name = "panel3";
            panel3.Size = new Size(153, 69);
            panel3.TabIndex = 15;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 5);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(94, 15);
            label3.TabIndex = 16;
            label3.Text = "Выбор режима:";
            // 
            // drPen
            // 
            drPen.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            drPen.Location = new Point(53, 44);
            drPen.Margin = new Padding(2, 2, 2, 2);
            drPen.Name = "drPen";
            drPen.Size = new Size(42, 21);
            drPen.TabIndex = 5;
            drPen.Text = "Pen";
            drPen.UseVisualStyleBackColor = true;
            drPen.Click += figure_Click;
            // 
            // drRentangle
            // 
            drRentangle.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            drRentangle.Location = new Point(99, 23);
            drRentangle.Margin = new Padding(2, 2, 2, 2);
            drRentangle.Name = "drRentangle";
            drRentangle.Size = new Size(42, 26);
            drRentangle.TabIndex = 4;
            drRentangle.Text = "Rntn";
            drRentangle.UseVisualStyleBackColor = true;
            drRentangle.Click += figure_Click;
            // 
            // drFill
            // 
            drFill.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            drFill.Location = new Point(7, 44);
            drFill.Margin = new Padding(2, 2, 2, 2);
            drFill.Name = "drFill";
            drFill.Size = new Size(42, 21);
            drFill.TabIndex = 2;
            drFill.Text = "Fill";
            drFill.UseVisualStyleBackColor = true;
            drFill.Click += figure_Click;
            // 
            // drEllips
            // 
            drEllips.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            drEllips.Location = new Point(53, 23);
            drEllips.Margin = new Padding(2, 2, 2, 2);
            drEllips.Name = "drEllips";
            drEllips.Size = new Size(42, 26);
            drEllips.TabIndex = 1;
            drEllips.Text = "Elps";
            drEllips.UseVisualStyleBackColor = true;
            drEllips.Click += figure_Click;
            // 
            // drLine
            // 
            drLine.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            drLine.Location = new Point(7, 22);
            drLine.Margin = new Padding(2, 2, 2, 2);
            drLine.Name = "drLine";
            drLine.Size = new Size(42, 27);
            drLine.TabIndex = 0;
            drLine.Text = "Line";
            drLine.UseVisualStyleBackColor = true;
            drLine.Click += figure_Click;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(lineWeight);
            panel2.Controls.Add(label2);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(238, 18);
            panel2.Margin = new Padding(2, 2, 2, 2);
            panel2.Name = "panel2";
            panel2.Size = new Size(141, 69);
            panel2.TabIndex = 12;
            // 
            // lineWeight
            // 
            lineWeight.Location = new Point(6, 23);
            lineWeight.Margin = new Padding(2, 2, 2, 2);
            lineWeight.Name = "lineWeight";
            lineWeight.Size = new Size(126, 45);
            lineWeight.TabIndex = 0;
            lineWeight.ValueChanged += lineWeight_ValueChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 5);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(103, 15);
            label2.TabIndex = 14;
            label2.Text = "Выбор толщины;";
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(clrPink);
            panel1.Controls.Add(clrBrown);
            panel1.Controls.Add(clrYellow);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(clrOrange);
            panel1.Controls.Add(clrViolet);
            panel1.Controls.Add(clrDarkBlue);
            panel1.Controls.Add(clrBlue);
            panel1.Controls.Add(clrGreen);
            panel1.Controls.Add(clrRed);
            panel1.Controls.Add(clrBlack);
            panel1.Controls.Add(clrGray);
            panel1.Controls.Add(clrWhite);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(97, 18);
            panel1.Margin = new Padding(2, 2, 2, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(141, 69);
            panel1.TabIndex = 2;
            // 
            // clrPink
            // 
            clrPink.BackColor = Color.HotPink;
            clrPink.Location = new Point(116, 44);
            clrPink.Margin = new Padding(2, 2, 2, 2);
            clrPink.Name = "clrPink";
            clrPink.Size = new Size(21, 18);
            clrPink.TabIndex = 11;
            clrPink.UseVisualStyleBackColor = false;
            clrPink.Click += color_Click;
            // 
            // clrBrown
            // 
            clrBrown.BackColor = Color.SaddleBrown;
            clrBrown.Location = new Point(93, 44);
            clrBrown.Margin = new Padding(2, 2, 2, 2);
            clrBrown.Name = "clrBrown";
            clrBrown.Size = new Size(21, 18);
            clrBrown.TabIndex = 10;
            clrBrown.UseVisualStyleBackColor = false;
            clrBrown.Click += color_Click;
            // 
            // clrYellow
            // 
            clrYellow.BackColor = Color.Yellow;
            clrYellow.Location = new Point(116, 23);
            clrYellow.Margin = new Padding(2, 2, 2, 2);
            clrYellow.Name = "clrYellow";
            clrYellow.Size = new Size(21, 18);
            clrYellow.TabIndex = 9;
            clrYellow.UseVisualStyleBackColor = false;
            clrYellow.Click += color_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(4, 5);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(87, 15);
            label1.TabIndex = 13;
            label1.Text = "Выбор цветов:";
            // 
            // clrOrange
            // 
            clrOrange.BackColor = Color.FromArgb(255, 128, 0);
            clrOrange.Location = new Point(93, 23);
            clrOrange.Margin = new Padding(2, 2, 2, 2);
            clrOrange.Name = "clrOrange";
            clrOrange.Size = new Size(21, 18);
            clrOrange.TabIndex = 8;
            clrOrange.UseVisualStyleBackColor = false;
            clrOrange.Click += color_Click;
            // 
            // clrViolet
            // 
            clrViolet.BackColor = Color.DarkViolet;
            clrViolet.Location = new Point(70, 44);
            clrViolet.Margin = new Padding(2, 2, 2, 2);
            clrViolet.Name = "clrViolet";
            clrViolet.Size = new Size(21, 18);
            clrViolet.TabIndex = 7;
            clrViolet.UseVisualStyleBackColor = false;
            clrViolet.Click += color_Click;
            // 
            // clrDarkBlue
            // 
            clrDarkBlue.BackColor = Color.Blue;
            clrDarkBlue.Location = new Point(48, 44);
            clrDarkBlue.Margin = new Padding(2, 2, 2, 2);
            clrDarkBlue.Name = "clrDarkBlue";
            clrDarkBlue.Size = new Size(21, 18);
            clrDarkBlue.TabIndex = 6;
            clrDarkBlue.UseVisualStyleBackColor = false;
            clrDarkBlue.Click += color_Click;
            // 
            // clrBlue
            // 
            clrBlue.BackColor = Color.DeepSkyBlue;
            clrBlue.Location = new Point(25, 44);
            clrBlue.Margin = new Padding(2, 2, 2, 2);
            clrBlue.Name = "clrBlue";
            clrBlue.Size = new Size(21, 18);
            clrBlue.TabIndex = 5;
            clrBlue.UseVisualStyleBackColor = false;
            clrBlue.Click += color_Click;
            // 
            // clrGreen
            // 
            clrGreen.BackColor = Color.Green;
            clrGreen.Location = new Point(3, 44);
            clrGreen.Margin = new Padding(2, 2, 2, 2);
            clrGreen.Name = "clrGreen";
            clrGreen.Size = new Size(21, 18);
            clrGreen.TabIndex = 4;
            clrGreen.UseVisualStyleBackColor = false;
            clrGreen.Click += color_Click;
            // 
            // clrRed
            // 
            clrRed.BackColor = Color.Red;
            clrRed.Location = new Point(70, 23);
            clrRed.Margin = new Padding(2, 2, 2, 2);
            clrRed.Name = "clrRed";
            clrRed.Size = new Size(21, 18);
            clrRed.TabIndex = 3;
            clrRed.UseVisualStyleBackColor = false;
            clrRed.Click += color_Click;
            // 
            // clrBlack
            // 
            clrBlack.BackColor = Color.Black;
            clrBlack.Location = new Point(48, 23);
            clrBlack.Margin = new Padding(2, 2, 2, 2);
            clrBlack.Name = "clrBlack";
            clrBlack.Size = new Size(21, 18);
            clrBlack.TabIndex = 2;
            clrBlack.UseVisualStyleBackColor = false;
            clrBlack.Click += color_Click;
            // 
            // clrGray
            // 
            clrGray.BackColor = Color.Gray;
            clrGray.Location = new Point(25, 23);
            clrGray.Margin = new Padding(2, 2, 2, 2);
            clrGray.Name = "clrGray";
            clrGray.Size = new Size(21, 18);
            clrGray.TabIndex = 1;
            clrGray.UseVisualStyleBackColor = false;
            clrGray.Click += color_Click;
            // 
            // clrWhite
            // 
            clrWhite.BackColor = Color.White;
            clrWhite.Location = new Point(3, 23);
            clrWhite.Margin = new Padding(2, 2, 2, 2);
            clrWhite.Name = "clrWhite";
            clrWhite.Size = new Size(21, 18);
            clrWhite.TabIndex = 0;
            clrWhite.UseVisualStyleBackColor = false;
            clrWhite.Click += color_Click;
            // 
            // clear
            // 
            clear.Dock = DockStyle.Left;
            clear.Location = new Point(47, 18);
            clear.Margin = new Padding(2, 2, 2, 2);
            clear.Name = "clear";
            clear.Size = new Size(50, 69);
            clear.TabIndex = 1;
            clear.Text = "Clear!";
            clear.UseVisualStyleBackColor = true;
            clear.Click += clear_Click;
            // 
            // save
            // 
            save.Dock = DockStyle.Left;
            save.Location = new Point(2, 18);
            save.Margin = new Padding(2, 2, 2, 2);
            save.Name = "save";
            save.Size = new Size(45, 69);
            save.TabIndex = 0;
            save.Text = "Save!";
            save.UseVisualStyleBackColor = true;
            save.Click += save_Click;
            // 
            // paintBox
            // 
            paintBox.BackColor = Color.White;
            paintBox.BorderStyle = BorderStyle.FixedSingle;
            paintBox.Dock = DockStyle.Fill;
            paintBox.Location = new Point(0, 89);
            paintBox.Margin = new Padding(2, 2, 2, 2);
            paintBox.Name = "paintBox";
            paintBox.Size = new Size(655, 246);
            paintBox.TabIndex = 1;
            paintBox.TabStop = false;
            paintBox.MouseDown += paintBox_MouseDown;
            paintBox.MouseMove += paintBox_MouseMove;
            paintBox.MouseUp += paintBox_MouseUp;
            // 
            // Paint
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.RosyBrown;
            ClientSize = new Size(655, 335);
            Controls.Add(paintBox);
            Controls.Add(groupBox1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(2, 2, 2, 2);
            Name = "Paint";
            Text = "Laboratory work 7 - Paint";
            groupBox1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)lineWeight).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)paintBox).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private Label label1;
        private Panel panel2;
        private TrackBar lineWeight;
        private Panel panel1;
        private Button clrPink;
        private Button clrBrown;
        private Button clrYellow;
        private Button clrOrange;
        private Button clrViolet;
        private Button clrDarkBlue;
        private Button clrBlue;
        private Button clrGreen;
        private Button clrRed;
        private Button clrBlack;
        private Button clrGray;
        private Button clrWhite;
        private Button clear;
        private Button save;
        private PictureBox paintBox;
        private SaveFileDialog saveFile;
        private Panel panel3;
        private Button drFill;
        private Button drEllips;
        private Button drLine;
        private Button drPen;
        private Button drRentangle;
        private Label label3;
    }
}