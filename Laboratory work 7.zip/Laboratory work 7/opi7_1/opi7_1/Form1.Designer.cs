﻿namespace opi7_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.drPen = new System.Windows.Forms.Button();
            this.drRentangle = new System.Windows.Forms.Button();
            this.drArc = new System.Windows.Forms.Button();
            this.drText = new System.Windows.Forms.Button();
            this.drEllips = new System.Windows.Forms.Button();
            this.drLine = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lineWeight = new System.Windows.Forms.TrackBar();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clrPink = new System.Windows.Forms.Button();
            this.clrBrown = new System.Windows.Forms.Button();
            this.clrYellow = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.clrOrange = new System.Windows.Forms.Button();
            this.clrViolet = new System.Windows.Forms.Button();
            this.clrDarkBlue = new System.Windows.Forms.Button();
            this.clrBlue = new System.Windows.Forms.Button();
            this.clrGreen = new System.Windows.Forms.Button();
            this.clrRed = new System.Windows.Forms.Button();
            this.clrBlack = new System.Windows.Forms.Button();
            this.clrGray = new System.Windows.Forms.Button();
            this.clrWhite = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.paintBox = new System.Windows.Forms.PictureBox();
            this.saveFile = new System.Windows.Forms.SaveFileDialog();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lineWeight)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paintBox)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.clear);
            this.groupBox1.Controls.Add(this.save);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(936, 148);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tools";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.drPen);
            this.panel3.Controls.Add(this.drRentangle);
            this.panel3.Controls.Add(this.drArc);
            this.panel3.Controls.Add(this.drText);
            this.panel3.Controls.Add(this.drEllips);
            this.panel3.Controls.Add(this.drLine);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(538, 27);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(217, 118);
            this.panel3.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 25);
            this.label3.TabIndex = 16;
            this.label3.Text = "Выбор режима:";
            // 
            // drPen
            // 
            this.drPen.Location = new System.Drawing.Point(142, 74);
            this.drPen.Name = "drPen";
            this.drPen.Size = new System.Drawing.Size(60, 30);
            this.drPen.TabIndex = 5;
            this.drPen.Text = "Pen";
            this.drPen.UseVisualStyleBackColor = true;
            this.drPen.Click += new System.EventHandler(this.figure_Click);
            // 
            // drRentangle
            // 
            this.drRentangle.Location = new System.Drawing.Point(142, 38);
            this.drRentangle.Name = "drRentangle";
            this.drRentangle.Size = new System.Drawing.Size(60, 30);
            this.drRentangle.TabIndex = 4;
            this.drRentangle.Text = "Rntn";
            this.drRentangle.UseVisualStyleBackColor = true;
            this.drRentangle.Click += new System.EventHandler(this.figure_Click);
            // 
            // drArc
            // 
            this.drArc.Location = new System.Drawing.Point(76, 74);
            this.drArc.Name = "drArc";
            this.drArc.Size = new System.Drawing.Size(60, 30);
            this.drArc.TabIndex = 3;
            this.drArc.Text = "Arc";
            this.drArc.UseVisualStyleBackColor = true;
            this.drArc.Click += new System.EventHandler(this.figure_Click);
            // 
            // drText
            // 
            this.drText.Location = new System.Drawing.Point(10, 74);
            this.drText.Name = "drText";
            this.drText.Size = new System.Drawing.Size(60, 30);
            this.drText.TabIndex = 2;
            this.drText.Text = "Text";
            this.drText.UseVisualStyleBackColor = true;
            this.drText.Click += new System.EventHandler(this.figure_Click);
            // 
            // drEllips
            // 
            this.drEllips.Location = new System.Drawing.Point(76, 38);
            this.drEllips.Name = "drEllips";
            this.drEllips.Size = new System.Drawing.Size(60, 30);
            this.drEllips.TabIndex = 1;
            this.drEllips.Text = "Elps";
            this.drEllips.UseVisualStyleBackColor = true;
            this.drEllips.Click += new System.EventHandler(this.figure_Click);
            // 
            // drLine
            // 
            this.drLine.Location = new System.Drawing.Point(10, 38);
            this.drLine.Name = "drLine";
            this.drLine.Size = new System.Drawing.Size(60, 30);
            this.drLine.TabIndex = 0;
            this.drLine.Text = "Line";
            this.drLine.UseVisualStyleBackColor = true;
            this.drLine.Click += new System.EventHandler(this.figure_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.lineWeight);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(338, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 118);
            this.panel2.TabIndex = 12;
            // 
            // lineWeight
            // 
            this.lineWeight.Location = new System.Drawing.Point(8, 39);
            this.lineWeight.Name = "lineWeight";
            this.lineWeight.Size = new System.Drawing.Size(180, 69);
            this.lineWeight.TabIndex = 0;
            this.lineWeight.ValueChanged += new System.EventHandler(this.lineWeight_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 25);
            this.label2.TabIndex = 14;
            this.label2.Text = "Выбор толщины;";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.clrPink);
            this.panel1.Controls.Add(this.clrBrown);
            this.panel1.Controls.Add(this.clrYellow);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.clrOrange);
            this.panel1.Controls.Add(this.clrViolet);
            this.panel1.Controls.Add(this.clrDarkBlue);
            this.panel1.Controls.Add(this.clrBlue);
            this.panel1.Controls.Add(this.clrGreen);
            this.panel1.Controls.Add(this.clrRed);
            this.panel1.Controls.Add(this.clrBlack);
            this.panel1.Controls.Add(this.clrGray);
            this.panel1.Controls.Add(this.clrWhite);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(138, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 118);
            this.panel1.TabIndex = 2;
            // 
            // clrPink
            // 
            this.clrPink.BackColor = System.Drawing.Color.HotPink;
            this.clrPink.Location = new System.Drawing.Point(165, 74);
            this.clrPink.Name = "clrPink";
            this.clrPink.Size = new System.Drawing.Size(30, 30);
            this.clrPink.TabIndex = 11;
            this.clrPink.UseVisualStyleBackColor = false;
            this.clrPink.Click += new System.EventHandler(this.color_Click);
            // 
            // clrBrown
            // 
            this.clrBrown.BackColor = System.Drawing.Color.SaddleBrown;
            this.clrBrown.Location = new System.Drawing.Point(133, 74);
            this.clrBrown.Name = "clrBrown";
            this.clrBrown.Size = new System.Drawing.Size(30, 30);
            this.clrBrown.TabIndex = 10;
            this.clrBrown.UseVisualStyleBackColor = false;
            this.clrBrown.Click += new System.EventHandler(this.color_Click);
            // 
            // clrYellow
            // 
            this.clrYellow.BackColor = System.Drawing.Color.Yellow;
            this.clrYellow.Location = new System.Drawing.Point(165, 38);
            this.clrYellow.Name = "clrYellow";
            this.clrYellow.Size = new System.Drawing.Size(30, 30);
            this.clrYellow.TabIndex = 9;
            this.clrYellow.UseVisualStyleBackColor = false;
            this.clrYellow.Click += new System.EventHandler(this.color_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Выбор цветов:";
            // 
            // clrOrange
            // 
            this.clrOrange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.clrOrange.Location = new System.Drawing.Point(133, 38);
            this.clrOrange.Name = "clrOrange";
            this.clrOrange.Size = new System.Drawing.Size(30, 30);
            this.clrOrange.TabIndex = 8;
            this.clrOrange.UseVisualStyleBackColor = false;
            this.clrOrange.Click += new System.EventHandler(this.color_Click);
            // 
            // clrViolet
            // 
            this.clrViolet.BackColor = System.Drawing.Color.DarkViolet;
            this.clrViolet.Location = new System.Drawing.Point(100, 74);
            this.clrViolet.Name = "clrViolet";
            this.clrViolet.Size = new System.Drawing.Size(30, 30);
            this.clrViolet.TabIndex = 7;
            this.clrViolet.UseVisualStyleBackColor = false;
            this.clrViolet.Click += new System.EventHandler(this.color_Click);
            // 
            // clrDarkBlue
            // 
            this.clrDarkBlue.BackColor = System.Drawing.Color.Blue;
            this.clrDarkBlue.Location = new System.Drawing.Point(68, 74);
            this.clrDarkBlue.Name = "clrDarkBlue";
            this.clrDarkBlue.Size = new System.Drawing.Size(30, 30);
            this.clrDarkBlue.TabIndex = 6;
            this.clrDarkBlue.UseVisualStyleBackColor = false;
            this.clrDarkBlue.Click += new System.EventHandler(this.color_Click);
            // 
            // clrBlue
            // 
            this.clrBlue.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.clrBlue.Location = new System.Drawing.Point(36, 74);
            this.clrBlue.Name = "clrBlue";
            this.clrBlue.Size = new System.Drawing.Size(30, 30);
            this.clrBlue.TabIndex = 5;
            this.clrBlue.UseVisualStyleBackColor = false;
            this.clrBlue.Click += new System.EventHandler(this.color_Click);
            // 
            // clrGreen
            // 
            this.clrGreen.BackColor = System.Drawing.Color.Green;
            this.clrGreen.Location = new System.Drawing.Point(4, 74);
            this.clrGreen.Name = "clrGreen";
            this.clrGreen.Size = new System.Drawing.Size(30, 30);
            this.clrGreen.TabIndex = 4;
            this.clrGreen.UseVisualStyleBackColor = false;
            this.clrGreen.Click += new System.EventHandler(this.color_Click);
            // 
            // clrRed
            // 
            this.clrRed.BackColor = System.Drawing.Color.Red;
            this.clrRed.Location = new System.Drawing.Point(100, 38);
            this.clrRed.Name = "clrRed";
            this.clrRed.Size = new System.Drawing.Size(30, 30);
            this.clrRed.TabIndex = 3;
            this.clrRed.UseVisualStyleBackColor = false;
            this.clrRed.Click += new System.EventHandler(this.color_Click);
            // 
            // clrBlack
            // 
            this.clrBlack.BackColor = System.Drawing.Color.Black;
            this.clrBlack.Location = new System.Drawing.Point(68, 38);
            this.clrBlack.Name = "clrBlack";
            this.clrBlack.Size = new System.Drawing.Size(30, 30);
            this.clrBlack.TabIndex = 2;
            this.clrBlack.UseVisualStyleBackColor = false;
            this.clrBlack.Click += new System.EventHandler(this.color_Click);
            // 
            // clrGray
            // 
            this.clrGray.BackColor = System.Drawing.Color.Gray;
            this.clrGray.Location = new System.Drawing.Point(36, 38);
            this.clrGray.Name = "clrGray";
            this.clrGray.Size = new System.Drawing.Size(30, 30);
            this.clrGray.TabIndex = 1;
            this.clrGray.UseVisualStyleBackColor = false;
            this.clrGray.Click += new System.EventHandler(this.color_Click);
            // 
            // clrWhite
            // 
            this.clrWhite.BackColor = System.Drawing.Color.White;
            this.clrWhite.Location = new System.Drawing.Point(4, 38);
            this.clrWhite.Name = "clrWhite";
            this.clrWhite.Size = new System.Drawing.Size(30, 30);
            this.clrWhite.TabIndex = 0;
            this.clrWhite.UseVisualStyleBackColor = false;
            this.clrWhite.Click += new System.EventHandler(this.color_Click);
            // 
            // clear
            // 
            this.clear.Dock = System.Windows.Forms.DockStyle.Left;
            this.clear.Location = new System.Drawing.Point(67, 27);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(71, 118);
            this.clear.TabIndex = 1;
            this.clear.Text = "Clear!";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // save
            // 
            this.save.Dock = System.Windows.Forms.DockStyle.Left;
            this.save.Location = new System.Drawing.Point(3, 27);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(64, 118);
            this.save.TabIndex = 0;
            this.save.Text = "Save!";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // paintBox
            // 
            this.paintBox.BackColor = System.Drawing.Color.White;
            this.paintBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paintBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.paintBox.Location = new System.Drawing.Point(0, 148);
            this.paintBox.Name = "paintBox";
            this.paintBox.Size = new System.Drawing.Size(936, 410);
            this.paintBox.TabIndex = 1;
            this.paintBox.TabStop = false;
            this.paintBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.paintBox_MouseDown);
            this.paintBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.paintBox_MouseMove);
            this.paintBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.paintBox_MouseUp);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(936, 558);
            this.Controls.Add(this.paintBox);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Laboratory work 7 - №1 - Paint";
            this.groupBox1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lineWeight)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paintBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private Label label1;
        private Panel panel2;
        private TrackBar lineWeight;
        private Panel panel1;
        private Button clrPink;
        private Button clrBrown;
        private Button clrYellow;
        private Button clrOrange;
        private Button clrViolet;
        private Button clrDarkBlue;
        private Button clrBlue;
        private Button clrGreen;
        private Button clrRed;
        private Button clrBlack;
        private Button clrGray;
        private Button clrWhite;
        private Button clear;
        private Button save;
        private PictureBox paintBox;
        private SaveFileDialog saveFile;
        private Panel panel3;
        private Button drArc;
        private Button drText;
        private Button drEllips;
        private Button drLine;
        private Button drPen;
        private Button drRentangle;
        private Label label3;
    }
}