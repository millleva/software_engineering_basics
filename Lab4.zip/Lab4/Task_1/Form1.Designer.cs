﻿namespace Task_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            archiveTextBox = new TextBox();
            dearchiveTextBox = new TextBox();
            archiveLabel = new Label();
            dearchiveLabel = new Label();
            archiveButton = new Button();
            dearchiveButton = new Button();
            SuspendLayout();
            // 
            // archiveTextBox
            // 
            archiveTextBox.Location = new Point(33, 69);
            archiveTextBox.Multiline = true;
            archiveTextBox.Name = "archiveTextBox";
            archiveTextBox.Size = new Size(130, 69);
            archiveTextBox.TabIndex = 0;
            // 
            // dearchiveTextBox
            // 
            dearchiveTextBox.Location = new Point(259, 69);
            dearchiveTextBox.Multiline = true;
            dearchiveTextBox.Name = "dearchiveTextBox";
            dearchiveTextBox.Size = new Size(130, 69);
            dearchiveTextBox.TabIndex = 1;
            // 
            // archiveLabel
            // 
            archiveLabel.AutoSize = true;
            archiveLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            archiveLabel.Location = new Point(33, 37);
            archiveLabel.Name = "archiveLabel";
            archiveLabel.Size = new Size(99, 21);
            archiveLabel.TabIndex = 2;
            archiveLabel.Text = "Archivation";
            // 
            // dearchiveLabel
            // 
            dearchiveLabel.AutoSize = true;
            dearchiveLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            dearchiveLabel.Location = new Point(259, 37);
            dearchiveLabel.Name = "dearchiveLabel";
            dearchiveLabel.Size = new Size(118, 21);
            dearchiveLabel.TabIndex = 3;
            dearchiveLabel.Text = "Dearchivation";
            // 
            // archiveButton
            // 
            archiveButton.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            archiveButton.Location = new Point(33, 156);
            archiveButton.Name = "archiveButton";
            archiveButton.Size = new Size(130, 28);
            archiveButton.TabIndex = 4;
            archiveButton.Text = "Archive";
            archiveButton.UseVisualStyleBackColor = true;
            archiveButton.Click += archiveButton_Click;
            // 
            // dearchiveButton
            // 
            dearchiveButton.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            dearchiveButton.Location = new Point(259, 156);
            dearchiveButton.Name = "dearchiveButton";
            dearchiveButton.Size = new Size(130, 28);
            dearchiveButton.TabIndex = 5;
            dearchiveButton.Text = "Dearchive";
            dearchiveButton.UseVisualStyleBackColor = true;
            dearchiveButton.Click += dearchiveButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(428, 255);
            Controls.Add(dearchiveButton);
            Controls.Add(archiveButton);
            Controls.Add(dearchiveLabel);
            Controls.Add(archiveLabel);
            Controls.Add(dearchiveTextBox);
            Controls.Add(archiveTextBox);
            Name = "Form1";
            Text = "Archiver";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox archiveTextBox;
        private TextBox dearchiveTextBox;
        private Label archiveLabel;
        private Label dearchiveLabel;
        private Button archiveButton;
        private Button dearchiveButton;
    }
}