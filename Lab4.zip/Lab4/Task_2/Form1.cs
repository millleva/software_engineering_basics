using System;
using System.IO;
using System.Windows.Forms;

namespace Task_2
{
    public partial class Form1 : Form
    {
        private const string FileName = "calculator_sessions.txt";

        public Form1()
        {
            InitializeComponent();
            LoadLastSession();
        }

        private void LoadLastSession()
        {
            if (File.Exists(FileName))
            {
                using (StreamReader reader = new StreamReader(FileName))
                {
                    inputTextBox.Text = reader.ReadLine();
                    outputTextBox.Text = reader.ReadLine();
                }
            }
        }

        private void SaveSession(string input, string output)
        {
            using (StreamWriter writer = new StreamWriter(FileName, true))
            {
                writer.WriteLine($"{input} = {output}");
            }
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;
            string[] parts = input.Split(' ');

            if (parts.Length == 3)
            {
                double firstOperand;
                double secondOperand;
                double result;

                if (double.TryParse(parts[0], out firstOperand) && double.TryParse(parts[2], out secondOperand))
                {
                    string operation = parts[1];

                    switch (operation.ToLower())
                    {
                        case "plus":
                        case "+":
                            result = firstOperand + secondOperand;
                            outputTextBox.Text = result.ToString();
                            break;
                        case "minus":
                        case "-":
                            result = firstOperand - secondOperand;
                            outputTextBox.Text = result.ToString();
                            break;
                        case "multiply":
                        case "*":
                            result = firstOperand * secondOperand;
                            outputTextBox.Text = result.ToString();
                            break;
                        case "divide":
                        case "/":
                            if (secondOperand != 0)
                            {
                                result = firstOperand / secondOperand;
                                outputTextBox.Text = result.ToString();
                            }
                            else
                            {
                                outputTextBox.Text = "Cannot divide by zero.";
                            }
                            break;
                        default:
                            outputTextBox.Text = "Invalid operation.";
                            break;
                    }

                    SaveSession(input, outputTextBox.Text);
                }
                else
                {
                    outputTextBox.Text = "Invalid input format.";
                }
            }
            else
            {
                outputTextBox.Text = "Invalid input format.";
            }
        }
    }
}
