﻿namespace Task_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            inputLabel = new Label();
            outputLabel = new Label();
            inputTextBox = new TextBox();
            outputTextBox = new TextBox();
            calculateButton = new Button();
            SuspendLayout();
            // 
            // inputLabel
            // 
            inputLabel.AutoSize = true;
            inputLabel.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            inputLabel.Location = new Point(51, 44);
            inputLabel.Name = "inputLabel";
            inputLabel.Size = new Size(53, 21);
            inputLabel.TabIndex = 0;
            inputLabel.Text = "Input:";
            // 
            // outputLabel
            // 
            outputLabel.AutoSize = true;
            outputLabel.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            outputLabel.Location = new Point(51, 176);
            outputLabel.Name = "outputLabel";
            outputLabel.Size = new Size(60, 21);
            outputLabel.TabIndex = 1;
            outputLabel.Text = "Ouput:";
            // 
            // inputTextBox
            // 
            inputTextBox.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            inputTextBox.Location = new Point(51, 73);
            inputTextBox.Name = "inputTextBox";
            inputTextBox.Size = new Size(189, 25);
            inputTextBox.TabIndex = 2;
            // 
            // outputTextBox
            // 
            outputTextBox.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            outputTextBox.Location = new Point(51, 206);
            outputTextBox.Name = "outputTextBox";
            outputTextBox.Size = new Size(189, 25);
            outputTextBox.TabIndex = 3;
            // 
            // calculateButton
            // 
            calculateButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            calculateButton.Location = new Point(101, 121);
            calculateButton.Name = "calculateButton";
            calculateButton.Size = new Size(82, 25);
            calculateButton.TabIndex = 4;
            calculateButton.Text = "Calculate";
            calculateButton.UseVisualStyleBackColor = true;
            calculateButton.Click += calculateButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(301, 299);
            Controls.Add(calculateButton);
            Controls.Add(outputTextBox);
            Controls.Add(inputTextBox);
            Controls.Add(outputLabel);
            Controls.Add(inputLabel);
            Name = "Form1";
            Text = "Task 2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label inputLabel;
        private Label outputLabel;
        private TextBox inputTextBox;
        private TextBox outputTextBox;
        private Button calculateButton;
    }
}