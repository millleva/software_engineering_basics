using System;
using System.IO;
using System.Windows.Forms;

namespace Task_3
{
    public partial class Form1 : Form
    {
        private const string FileName = "string_operations_sessions.txt";

        public Form1()
        {
            InitializeComponent();
            LoadLastSession();
        }

        private void LoadLastSession()
        {
            if (File.Exists(FileName))
            {
                using (StreamReader reader = new StreamReader(FileName))
                {
                    textBox1.Text = reader.ReadLine();
                    textBox2.Text = reader.ReadLine();
                    compareOrdinalButton_Click(null, EventArgs.Empty);

                    textBox3.Text = reader.ReadLine();
                    startIndexTextBox.Text = reader.ReadLine();
                    lengthTextBox.Text = reader.ReadLine();
                    substringButton_Click(null, EventArgs.Empty);
                }
            }
        }

        private void SaveSession(string sessionData)
        {
            using (StreamWriter writer = new StreamWriter(FileName, true))
            {
                writer.WriteLine(sessionData);
            }
        }

        private void compareOrdinalButton_Click(object sender, EventArgs e)
        {
            string str1 = textBox1.Text;
            string str2 = textBox2.Text;

            int result = string.CompareOrdinal(str1, str2);

            if (result < 0)
            {
                compareOrdinalResult.Text = "String 1 < string 2";
            }
            else if (result > 0)
            {
                compareOrdinalResult.Text = "String 1 > string 2";
            }
            else
            {
                compareOrdinalResult.Text = "Strings are even";
            }

            SaveSession($"CompareOrdinal: {str1}, {str2} => {compareOrdinalResult.Text}");
        }

        private void compareToButton_Click(object sender, EventArgs e)
        {
            string text1 = textBox1.Text;
            string text2 = textBox2.Text;

            int result = text1.CompareTo(text2);

            if (result < 0)
            {
                compareToResult.Text = "String 1 < string 2";
            }
            else if (result > 0)
            {
                compareToResult.Text = "String 1 > string 2";
            }
            else
            {
                compareToResult.Text = "Strings are even";
            }

            SaveSession($"CompareTo: {text1}, {text2} => {compareToResult.Text}");
        }

        private void substringButton_Click(object sender, EventArgs e)
        {
            string input = textBox3.Text;
            int startIndex = int.Parse(startIndexTextBox.Text);
            int length = int.Parse(lengthTextBox.Text);

            string substring = input.Substring(startIndex, length);

            substringResult.Text = "Substring: " + substring;

            SaveSession($"Substring: {input}, {startIndex}, {length} => {substringResult.Text}");
        }
    }
}
