namespace Task_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.Text = textBox1.Text;
            }

            if (checkBox2.Checked)
            {
                textBox3.Text = textBox1.Text;
            }

        }
    }
}